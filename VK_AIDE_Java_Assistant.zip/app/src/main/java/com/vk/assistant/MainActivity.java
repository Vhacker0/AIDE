package com.vk.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.RecognizerIntent;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private TextToSpeech tts;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);

        Button listenBtn = findViewById(R.id.listenBtn);
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.ERROR) {
                tts.setLanguage(Locale.forLanguageTag("hi-IN"));
                tts.speak("नमस्ते, मैं VK असिस्टेंट हूँ", TextToSpeech.QUEUE_FLUSH, null, null);
            }
        });

        listenBtn.setOnClickListener(v -> {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            startActivityForResult(intent, 100);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String command = result.get(0);
            textView.setText(command);

            if (command.contains("समय") || command.contains("time")) {
                tts.speak("अभी समय बताना संभव नहीं है, पर मैं सीख रहा हूँ", TextToSpeech.QUEUE_FLUSH, null, null);
            } else if (command.contains("बंद")) {
                tts.speak("ठीक है, अलविदा", TextToSpeech.QUEUE_FLUSH, null, null);
                finish();
            } else {
                tts.speak("माफ़ कीजिए, मैं समझ नहीं पाया", TextToSpeech.QUEUE_FLUSH, null, null);
            }
        }
    }
}
